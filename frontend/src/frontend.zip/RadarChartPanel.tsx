import React from "react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, Legend, ResponsiveContainer } from "recharts";

interface RadarChartPanelProps {
  data: { site: string; section: string }[];
}

const RadarChartPanel: React.FC<RadarChartPanelProps> = ({ data }) => {
  const sections = Array.from(new Set(data.map(d => d.section)));
  const sites = Array.from(new Set(data.map(d => d.site)));

  const siteDataMap: Record<string, Record<string, number>> = {};
  data.forEach(row => {
    if (!siteDataMap[row.site]) siteDataMap[row.site] = {};
    if (!siteDataMap[row.site][row.section]) siteDataMap[row.site][row.section] = 0;
    siteDataMap[row.site][row.section]++;
  });

  const chartData = sections.map(section => {
    const entry: any = { section };
    sites.forEach(site => {
      entry[site] = siteDataMap[site]?.[section] || 0;
    });
    return entry;
  });

  return (
    <ResponsiveContainer width="100%" height={400}>
      <RadarChart data={chartData}>
        <PolarGrid />
        <PolarAngleAxis dataKey="section" />
        {sites.map((site, idx) => (
          <Radar
            key={site}
            name={site}
            dataKey={site}
            stroke="#8884d8"
            fill="#8884d8"
            fillOpacity={0.4}
          />
        ))}
        <Legend />
      </RadarChart>
    </ResponsiveContainer>
  );
};

export default RadarChartPanel;
