// src/Dashboard.tsx
import React from 'react';
import Upload from './Upload';

const Dashboard = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">CTS Admin Dashboard</h1>
      <p className="mb-6 text-gray-700">
        Upload profiling or qualification questionnaires here to ingest data into the system.
      </p>
      <Upload onUploadSuccess={() => window.location.reload()} />
    </div>
  );
};

export default Dashboard;