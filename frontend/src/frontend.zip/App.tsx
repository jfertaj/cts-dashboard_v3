// src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import {
  FileSearchOutlined,
  UploadOutlined,
} from '@ant-design/icons';

import Explorer from './Explorer';
import Dashboard from './Dashboard';

const { Header, Content } = Layout;

const App = () => {
  const location = useLocation();

  return (
    <Layout className="min-h-screen">
      <Header className="bg-white shadow-md px-6">
        <Menu
          mode="horizontal"
          selectedKeys={[location.pathname]}
          theme="light"
        >
          <Menu.Item key="/" icon={<FileSearchOutlined />}>
            <Link to="/">Explorer</Link>
          </Menu.Item>
          <Menu.Item key="/dashboard" icon={<UploadOutlined />}>
            <Link to="/dashboard">Dashboard</Link>
          </Menu.Item>
        </Menu>
      </Header>
      <Content className="p-6">
        <Routes>
          <Route path="/" element={<Explorer />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </Content>
    </Layout>
  );
};


export default App;