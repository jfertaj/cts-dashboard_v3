// src/Upload.tsx
import React, { useState, useEffect, DragEvent, useRef } from 'react';
import axios from 'axios';
import { TailSpin } from 'react-loader-spinner';

type UploadProps = {
  onUploadSuccess?: () => void;
};

const Upload: React.FC<UploadProps> = ({ onUploadSuccess }) => {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string>('');
  const [dragging, setDragging] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [data, setData] = useState<any[]>([]);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    fetchUpdatedData();
  }, []);

  const handleFileDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.name.endsWith(".xlsx")) {
      setFile(droppedFile);
      setStatus('');
    } else {
      setStatus("❌ Only .xlsx files are supported.");
    }
    setDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(false);
  };

  const handleUpload = async () => {
    if (!file) {
      setStatus('❌ Please select a file first.');
      return;
    }

    setIsUploading(true);
    setStatus('⏳ Uploading...');
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('/api/upload/', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      const data = response.data;
      setStatus(`✅ Uploaded: ${data.filename || file.name} as ${data.form_type || 'unknown'}`);
      fetchUpdatedData();
      if (onUploadSuccess) onUploadSuccess(); // notify Explorer to refresh
    } catch (error: any) {
      setStatus('');
      alert(`❌ Upload failed: ${error?.response?.data?.detail || error.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const fetchUpdatedData = async () => {
    setLoading(true);
    try {
      const response = await axios.get('/api/responses/');
      setData(response.data);
    } catch (error) {
      console.error('Error fetching updated data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mb-8 border p-4 rounded-lg shadow-sm bg-white">
      <h2 className="text-xl font-semibold mb-2">📤 Upload Excel File</h2>

      <div
        className={`w-full p-6 border-2 border-dashed rounded-lg text-center cursor-pointer transition-all duration-300 ${
          dragging ? 'bg-blue-100 border-blue-400' : 'bg-gray-50 border-gray-300'
        }`}
        onClick={() => inputRef.current?.click()}
        onDrop={handleFileDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        <p className="text-sm text-gray-700">Drag & drop your Excel (.xlsx) file here</p>
        <p className="text-xs text-gray-500 mt-1">or click to select</p>
        <input
          type="file"
          accept=".xlsx"
          className="hidden"
          ref={inputRef}
          onChange={(e) => {
            const selectedFile = e.target.files?.[0];
            if (selectedFile) {
              setFile(selectedFile);
              setStatus('');
            }
          }}
        />
      </div>

      {file && <p className="mt-2 text-sm">Selected: <strong>{file.name}</strong></p>}

      <button
        className={`mt-4 px-4 py-2 rounded text-white ${isUploading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}`}
        onClick={handleUpload}
        disabled={!file || isUploading}
      >
        {isUploading ? (
          <div className="flex items-center justify-center gap-2">
            <TailSpin height="20" width="20" color="#ffffff" />
            Uploading...
          </div>
        ) : (
          'Upload'
        )}
      </button>

      {status && <p className="mt-2 text-sm">{status}</p>}

      {loading && (
        <div className="mt-4 flex items-center gap-2 text-gray-500">
          <TailSpin height="20" width="20" color="#888" />
          <span>Loading existing data...</span>
        </div>
      )}

      {!loading && !isUploading && data.length === 0 && (
        <p className="mt-4 text-sm text-gray-500">
          📭 The database is empty. Please upload a questionnaire to get started.
        </p>
      )}
    </div>
  );
};

export default Upload;