// frontend/src/FilterExplorer.tsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Select, Table } from "antd";
import { ResponseRecord } from "./types";

const FilterExplorer = () => {
  const [data, setData] = useState<ResponseRecord[]>([]);
  const [sections, setSections] = useState<string[]>([]);
  const [questions, setQuestions] = useState<string[]>([]);
  const [answers, setAnswers] = useState<string[]>([]);

  const [selectedSection, setSelectedSection] = useState<string | undefined>();
  const [selectedQuestion, setSelectedQuestion] = useState<string | undefined>();
  const [selectedAnswer, setSelectedAnswer] = useState<string | undefined>();

  const [filtered, setFiltered] = useState<ResponseRecord[]>([]);

  useEffect(() => {
    axios.get<ResponseRecord[]>("/api/responses").then((res) => {
      setData(res.data);
      setSections([...new Set(res.data.map((r) => r.section))]);
    });
  }, []);

  useEffect(() => {
    if (selectedSection) {
      const qs = data
        .filter((r) => r.section === selectedSection)
        .map((r) => r.question);
      setQuestions([...new Set(qs)]);
    } else {
      setQuestions([]);
    }
    setSelectedQuestion(undefined);
    setSelectedAnswer(undefined);
  }, [selectedSection]);

  useEffect(() => {
    if (selectedQuestion) {
      const as = data
        .filter((r) => r.question === selectedQuestion)
        .map((r) => r.answer);
      setAnswers([...new Set(as)]);
    } else {
      setAnswers([]);
    }
    setSelectedAnswer(undefined);
  }, [selectedQuestion]);

  useEffect(() => {
    let filteredData = data;
    if (selectedSection)
      filteredData = filteredData.filter((r) => r.section === selectedSection);
    if (selectedQuestion)
      filteredData = filteredData.filter((r) => r.question === selectedQuestion);
    if (selectedAnswer)
      filteredData = filteredData.filter((r) => r.answer === selectedAnswer);

    setFiltered(filteredData);
  }, [data, selectedSection, selectedQuestion, selectedAnswer]);

  const columns = [
    { title: "Site", dataIndex: "site", key: "site" },
    { title: "Version", dataIndex: "version", key: "version" },
    { title: "Type", dataIndex: "type", key: "type" },
    { title: "Section", dataIndex: "section", key: "section" },
    { title: "Question", dataIndex: "question", key: "question" },
    { title: "Answer", dataIndex: "answer", key: "answer" },
    { title: "Subsection", dataIndex: "subsection", key: "subsection" }
  ];

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Advanced Filter Explorer</h2>

      <div className="flex space-x-4 mb-6">
        <Select
          placeholder="Select Section"
          style={{ width: 220 }}
          onChange={setSelectedSection}
          value={selectedSection}
          allowClear
        >
          {sections.map((s) => (
            <Select.Option key={s} value={s}>{s}</Select.Option>
          ))}
        </Select>

        <Select
          placeholder="Select Question"
          style={{ width: 300 }}
          onChange={setSelectedQuestion}
          value={selectedQuestion}
          allowClear
          disabled={!selectedSection}
        >
          {questions.map((q) => (
            <Select.Option key={q} value={q}>{q}</Select.Option>
          ))}
        </Select>

        <Select
          placeholder="Select Answer"
          style={{ width: 200 }}
          onChange={setSelectedAnswer}
          value={selectedAnswer}
          allowClear
          disabled={!selectedQuestion}
        >
          {answers.map((a) => (
            <Select.Option key={a} value={a}>{a}</Select.Option>
          ))}
        </Select>
      </div>

      <Table
        columns={columns}
        dataSource={filtered.map((r, i) => ({ ...r, key: i }))}
        pagination={{ pageSize: 10 }}
      />
    </div>
  );
};

export default FilterExplorer;