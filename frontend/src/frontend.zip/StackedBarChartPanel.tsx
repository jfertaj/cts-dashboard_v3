import React from "react";
import { BarChart, XAxis, YAxis, Tooltip, Legend, Bar, ResponsiveContainer } from "recharts";

interface StackedChartProps {
  data: { site: string; section: string }[];
}

const StackedBarChartPanel: React.FC<StackedChartProps> = ({ data }) => {
  const sites = Array.from(new Set(data.map(d => d.site)));
  const sections = Array.from(new Set(data.map(d => d.section)));

  const grouped: Record<string, Record<string, number>> = {};
  data.forEach(row => {
    if (!grouped[row.site]) grouped[row.site] = {};
    if (!grouped[row.site][row.section]) grouped[row.site][row.section] = 0;
    grouped[row.site][row.section]++;
  });

  const chartData = sites.map(site => {
    const entry: any = { site };
    sections.forEach(section => {
      entry[section] = grouped[site]?.[section] || 0;
    });
    return entry;
  });

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart data={chartData}>
        <XAxis dataKey="site" />
        <YAxis />
        <Tooltip />
        <Legend />
        {sections.map(section => (
          <Bar
            key={section}
            dataKey={section}
            stackId="a"
            fill="#8884d8"
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
};

export default StackedBarChartPanel;
