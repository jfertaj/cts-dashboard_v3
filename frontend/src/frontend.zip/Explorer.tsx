// src/Explorer.tsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Table, Select, Button, Input, InputNumber, message, Tooltip, Modal,
} from "antd";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-cluster";
import { v4 as uuidv4 } from "uuid";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { ResponseRecord } from "./types";
// Fix marker icons for leaflet
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';


type LogicalOperator = "AND" | "OR";
type ValueType = "text" | "categorical" | "numeric";

interface FilterRule {
  id: string;
  section: string;
  subsection?: string;
  question: string;
  operator?: string;
  value: string | number;
  type: ValueType;
}

interface SiteCoord {
  site: string;
  latitude: number;
  longitude: number;
  city?: string;
  country?: string;
}


// Fix marker icons for Leaflet in Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const defaultCenter: [number, number] = [48, 10];

const Explorer = () => {
  const [data, setData] = useState<ResponseRecord[]>([]);
  const [filteredData, setFilteredData] = useState<ResponseRecord[]>([]);
  const [siteCoords, setSiteCoords] = useState<SiteCoord[]>([]);
  const [sections, setSections] = useState<string[]>([]);
  const [subsectionsBySection, setSubsectionsBySection] = useState<Record<string, string[]>>({});
  const [questionsBySubsection, setQuestionsBySubsection] = useState<Record<string, string[]>>({});
  const [answersByQuestion, setAnswersByQuestion] = useState<Record<string, string[]>>({});
  const [cities, setCities] = useState<string[]>([]);
  const [countries, setCountries] = useState<string[]>([]);
  const [cityFilter, setCityFilter] = useState<string>();
  const [countryFilter, setCountryFilter] = useState<string>();
  const [ruleList, setRuleList] = useState<FilterRule[]>([]);
  const [logic, setLogic] = useState<LogicalOperator>("AND");
  const [templateModal, setTemplateModal] = useState(false);
  const [templateName, setTemplateName] = useState("");
  const [savedTemplates, setSavedTemplates] = useState<Record<string, any>>({});

  useEffect(() => {
    axios.get<ResponseRecord[]>("/api/responses").then(res => {
      const all = res.data;
      setData(all);
      setFilteredData(all);

      const secSet = new Set<string>();
      const subMap: Record<string, Set<string>> = {};
      const qMap: Record<string, Set<string>> = {};
      const aMap: Record<string, Set<string>> = {};
      const citySet = new Set<string>();
      const countrySet = new Set<string>();

      for (const row of all) {
        secSet.add(row.section);
        if (row.subsection) {
          if (!subMap[row.section]) subMap[row.section] = new Set();
          subMap[row.section].add(row.subsection);
        }
        const qKey = `${row.section}|${row.subsection || ""}`;
        if (!qMap[qKey]) qMap[qKey] = new Set();
        qMap[qKey].add(row.question);

        if (!aMap[row.question]) aMap[row.question] = new Set();
        aMap[row.question].add(row.answer);

        if (row.city) citySet.add(row.city);
        if (row.country) countrySet.add(row.country);
      }

      setSections(Array.from(secSet));
      setSubsectionsBySection(Object.fromEntries(Object.entries(subMap).map(([k, v]) => [k, Array.from(v)])));
      setQuestionsBySubsection(Object.fromEntries(Object.entries(qMap).map(([k, v]) => [k, Array.from(v)])));
      setAnswersByQuestion(Object.fromEntries(Object.entries(aMap).map(([k, v]) => [k, Array.from(v)])));
      setCities(Array.from(citySet));
      setCountries(Array.from(countrySet));

      const stored = localStorage.getItem("filterTemplates");
      if (stored) setSavedTemplates(JSON.parse(stored));

      // Show all geolocated cities on first load
      const uniqueSites = Array.from(
        new Map(
          all
            .filter(r => r.latitude && r.longitude)
            .map(row => [row.site, {
              site: row.site,
              latitude: row.latitude,
              longitude: row.longitude,
              city: row.city,
              country: row.country
            }])
        ).values()
      );
      setSiteCoords(uniqueSites);
    });
  }, []);

  const detectType = (answers: string[]): ValueType => {
    const cleaned = answers.filter(a =>
      a && !["n/a", "no response provided", "na"].includes(a.trim().toLowerCase())
    );
    const validCount = cleaned.length;
    const numericCount = cleaned.filter(a => !isNaN(parseFloat(a))).length;
    if (validCount > 0 && numericCount / validCount >= 0.6) return "numeric";
    const uniqueCount = new Set(cleaned).size;
    return uniqueCount <= 20 ? "categorical" : "text";
  };

  const addFilter = () => {
    setRuleList(prev => [...prev, {
      id: uuidv4(), section: "", subsection: "", question: "", value: "", type: "text", operator: "equals"
    }]);
  };

  const updateRule = (id: string, key: keyof FilterRule, value: any) => {
    setRuleList(prev => prev.map(rule => rule.id === id ? { ...rule, [key]: value } : rule));
  };

  const removeRule = (id: string) => {
    setRuleList(prev => prev.filter(rule => rule.id !== id));
  };

  const applyFilters = async () => {
    try {
      const filters = ruleList.map(rule => ({
        section: rule.section,
        subsection: rule.subsection,
        question: rule.question,
        operator: rule.operator,
        value: rule.value
      }));

      const body: any = { logic, rules: filters };
      if (cityFilter) body.city = cityFilter;
      if (countryFilter) body.country = countryFilter;

      const res = await axios.post("/api/filter-responses/", body);
      const filtered = res.data;
      setFilteredData(filtered);

      const uniqueSites = Array.from(
        new Map(filtered
          .filter(r => r.latitude && r.longitude)
          .map(row => [row.site, {
            site: row.site,
            latitude: row.latitude,
            longitude: row.longitude,
            city: row.city,
            country: row.country
          }])
        ).values()
      );
      setSiteCoords(uniqueSites);
      if (!filtered.length) message.warning("No results match the filters.");
    } catch (err) {
      console.error(err);
      message.error("Filter request failed");
    }
  };

  const resetFilters = () => {
    setRuleList([]);
    setCityFilter(undefined);
    setCountryFilter(undefined);
    setFilteredData(data);

    const allCoords = Array.from(
      new Map(
        data
          .filter(r => r.latitude && r.longitude)
          .map(row => [row.site, {
            site: row.site,
            latitude: row.latitude,
            longitude: row.longitude,
            city: row.city,
            country: row.country
          }])
      ).values()
    );
    setSiteCoords(allCoords);
    message.info("Filters reset.");
  };

  const renderAnswerInput = (rule: FilterRule) => {
    const answers = answersByQuestion[rule.question] || [];
    const type = detectType(answers);
    rule.type = type;

    if (type === "categorical") {
      return (
        <Select value={rule.value as string} style={{ width: 160 }}
          onChange={val => updateRule(rule.id, "value", val)}>
          {answers.map(a => <Select.Option key={a} value={a}>{a}</Select.Option>)}
        </Select>
      );
    }

    if (type === "numeric") {
      return (
        <>
          <Select value={rule.operator} style={{ width: 80 }}
            onChange={val => updateRule(rule.id, "operator", val)}>
            <Select.Option value=">">{" > "}</Select.Option>
            <Select.Option value="<">{" < "}</Select.Option>
            <Select.Option value="=">{" = "}</Select.Option>
          </Select>
          <InputNumber value={rule.value as number}
            onChange={val => updateRule(rule.id, "value", val ?? 0)} />
        </>
      );
    }

    return (
      <>
        <Select value={rule.operator} style={{ width: 140 }}
          onChange={val => updateRule(rule.id, "operator", val)}>
          <Select.Option value="equals">equals</Select.Option>
          <Select.Option value="contains">contains</Select.Option>
          <Select.Option value="not contains">not contains</Select.Option>
        </Select>
        <Input value={rule.value as string}
          onChange={e => updateRule(rule.id, "value", e.target.value)}
          style={{ width: 180 }} />
      </>
    );
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">CTS Smart Filter Explorer</h2>

      <div className="flex items-center gap-4 mb-4">
        <Tooltip title="Add a new rule to filter by Section → Subsection → Question">
          <Button onClick={addFilter}>+ Add Rule</Button>
        </Tooltip>
        <Tooltip title="Logical operator between rules">
          <Select value={logic} onChange={setLogic}>
            <Select.Option value="AND">AND</Select.Option>
            <Select.Option value="OR">OR</Select.Option>
          </Select>
        </Tooltip>
        <Button onClick={applyFilters} type="primary">Apply Filters</Button>
        <Button onClick={resetFilters}>Reset Filters</Button>
      </div>

      <div className="flex gap-4 mb-6">
        <Select placeholder="Filter by City" style={{ width: 200 }} value={cityFilter} onChange={setCityFilter} allowClear>
          {cities.map(c => <Select.Option key={c} value={c}>{c}</Select.Option>)}
        </Select>
        <Select placeholder="Filter by Country" style={{ width: 200 }} value={countryFilter} onChange={setCountryFilter} allowClear>
          {countries.map(c => <Select.Option key={c} value={c}>{c}</Select.Option>)}
        </Select>
      </div>

      {ruleList.map(rule => (
        <div key={rule.id} className="flex gap-2 mb-2">
          <Select
            placeholder="Section"
            value={rule.section}
            onChange={val => {
              updateRule(rule.id, "section", val);
              updateRule(rule.id, "subsection", "");
              updateRule(rule.id, "question", "");
              updateRule(rule.id, "value", "");
            }}
            style={{ width: 180 }}
          >
            {sections.map(s => <Select.Option key={s} value={s}>{s}</Select.Option>)}
          </Select>

          <Select
            placeholder="Subsection"
            value={rule.subsection}
            onChange={val => {
              updateRule(rule.id, "subsection", val);
              updateRule(rule.id, "question", "");
              updateRule(rule.id, "value", "");
            }}
            disabled={!rule.section}
            style={{ width: 200 }}
          >
            {(subsectionsBySection[rule.section] || []).map(ss => (
              <Select.Option key={ss} value={ss}>{ss}</Select.Option>
            ))}
          </Select>

          <Select
            placeholder="Question"
            value={rule.question}
            onChange={val => {
              updateRule(rule.id, "question", val);
              updateRule(rule.id, "value", "");
            }}
            disabled={!rule.subsection && subsectionsBySection[rule.section]?.length > 0}
            style={{ width: 280 }}
          >
            {(questionsBySubsection[`${rule.section}|${rule.subsection}`] || []).map(q => (
              <Select.Option key={q} value={q}>{q}</Select.Option>
            ))}
          </Select>

          {renderAnswerInput(rule)}
          <Button danger onClick={() => removeRule(rule.id)}>Remove</Button>
        </div>
      ))}

      <MapContainer center={defaultCenter} zoom={3} style={{ height: 400, marginTop: 20 }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <MarkerClusterGroup>
          {siteCoords.map((site, i) => (
            <Marker key={i} position={[site.latitude, site.longitude]}>
              <Popup>
                <strong>{site.site}</strong><br />
                {site.city && <div>{site.city}</div>}
                {site.country && <div>{site.country}</div>}
              </Popup>
            </Marker>
          ))}
        </MarkerClusterGroup>
      </MapContainer>

      <Table
        dataSource={filteredData.map((r, i) => ({ ...r, key: i }))}
        columns={[
          { title: "Site", dataIndex: "site" },
          { title: "Section", dataIndex: "section" },
          { title: "Subsection", dataIndex: "subsection" },
          { title: "Question", dataIndex: "question" },
          { title: "Answer", dataIndex: "answer" },
        ]}
        pagination={{ pageSize: 10 }}
        className="mt-6"
      />
    </div>
  );
};

export default Explorer;